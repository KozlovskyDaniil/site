<?php
	# Installation
	define('INSTALL','1');

	# User
	define('USER_USERNAME','user');
	define('USER_PASSWORD','356a192b7913b04c54574d18c28d46e6395428ab');
	define('USER_LANGUAGE','en-US');
	define('USER_FONT_FAMILY','1');
	define('USER_FONT_SIZE','1');
	define('USER_FONT_COLOR','1');
	define('USER_EDIT_TITLE','1');
	define('USER_EDIT_KEYWORDS','1');
	define('USER_EDIT_DESCRIPTION','1');
	define('USER_DELETE_PAGES','1');
	define('USER_ADD_NEW_PAGES','1');

	# Administrator
	define('ADMINISTRATOR_USERNAME','admin');
	define('ADMINISTRATOR_PASSWORD','356a192b7913b04c54574d18c28d46e6395428ab');
	define('ADMINISTRATOR_LANGUAGE','en-US');

	# FTP
	define('FTP_ENABLED','0');
	define('FTP_HOST','');
	define('FTP_PORT','');
	define('FTP_PASSIVE_MODE','');
	define('FTP_USERNAME','');
	define('FTP_PASSWORD','');
	define('FTP_ROOT_DIRECTORY','');

	# Paths
	define('SERVER_ADDR','');
	define('WEBSITE_URL','');
	define('ROOT_DIRECTORY','');
	define('UPLOAD_DIRECTORY','');
	define('EXCLUDE_DIRECTORIES','admin,css');

	# Charset
	define('CHARSET','iso-8859-1');

	# Misc
	define('IGNORE_EDITABLE_REGION_NAMES','doctitle,head');
	define('TOLERATE_PATHS','');
	define('EDITOR_WIDTH','100%');
	define('EDITOR_HEIGHT','375px');
	define('ALLOWED_EXTENSIONS','htm,html,php,shtml,phtml,php3,php4,php5,asp,aspx');
	define('EDITABLE_REGION_TAGS_START','<!-- TemplateBeginEditable name="%s" -->,<!-- InstanceBeginEditable name="%s" -->');
	define('EDITABLE_REGION_TAGS_END','<!-- TemplateEndEditable -->,<!-- InstanceEndEditable -->');
	define('DEBUG_MODE','0');
	define('DEMO_MODE','0');
	define('BLOWFISH','');
?>